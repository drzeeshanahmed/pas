//
//  cls_ViewController_ICD10.swift
//  PAS-Code
//
//  Created by Zeeshan Ahmed.
//  Copyright � 2018 Zeeshan Ahmed. All rights reserved.
//

import UIKit

class cls_ViewController_ICD10: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var lbl_Menu_User_ID_Email: UILabel!
    var str_User_ID_Navigated = ""
    var str_ICD_Type = ""

    @IBOutlet weak var txt_Search: UITextField!
    
    @IBOutlet weak var txt_Search_Results: UITextView!
    
    @IBOutlet weak var lbl_search_results: UILabel!
    
    @IBOutlet weak var lbl_ViewController_Header: UILabel!
    
    @IBOutlet weak var lbl_Total: UILabel!
    
    var hosting_server = ""
    
    let ACCEPTABLE_CHARACTERS = "ABC"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(hosting_server)
        
        lbl_Menu_User_ID_Email.text = str_User_ID_Navigated
        lbl_ViewController_Header.text = str_ICD_Type

        self.txt_Search.delegate = self

        // Do any additional setup after loading the view.
    }
    
    //Invoke touch screen
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    //Invoke Return
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txt_Search.resignFirstResponder()
        return (true)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        //Code to run any event at execution.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let cs = CharacterSet(charactersIn: ACCEPTABLE_CHARACTERS).inverted
        let filtered: String = (string.components(separatedBy: cs) as NSArray).componentsJoined(by: "")
        return (string == filtered)
    }
    
    @IBAction func btn_Search(_ sender: Any) {
        self.txt_Search_Results.text = ""
        search_Keyword()
    }
    
    //Search
    func search_Keyword()
    {
        let str_Keyword = txt_Search.text;
        
        if str_Keyword != ""
        {
            var phpfilename = "tmp_2.php"
            
            
            let myURL = NSURL(string: hosting_server + phpfilename);
            
            let request = NSMutableURLRequest(url:myURL! as URL);
            request.httpMethod = "POST";
            
            let postString = "keyword=\(str_Keyword!)";
            
            request.httpBody = postString.data(using: String.Encoding.utf8);
            
            //creating a task to send the post request
            let task = URLSession.shared.dataTask(with: request as URLRequest){
                data, response, error in
                
                if error != nil{
                    print("Session Error \(error)")
                    return;
                }
                else{
                    print("No Session Error")
                }
                
                //parsing the response
                do {
                    //converting resonse to NSDictionary
                    let myJSON =  try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    
                    //getting the JSON array teams from the response
                    let let_results: NSArray = myJSON!["results"] as! NSArray
                    self.Arr_Search_Results(arr_results: let_results)
                    
                } catch {
                    print(error)
                }
            }
            task.resume();
        }
        else
        {
            self.Alert(Message: "Please enter value to search")

        }
    }
    
    
    //Search results
    func Arr_Search_Results (arr_results: NSArray){
        print("---Array---")
        
        print ("Total: " + String(arr_results.count))
        
        DispatchQueue.main.async {
            
            //looping through all the json objects in the array teams
            self.lbl_Total.text = "Total: " + String(arr_results.count)

            //looping through all the json objects in the array teams
            for i in 0 ..< arr_results.count{
                //print(teams[i] as! NSDictionary)
                
                print("===================")
                
                let let_ICD_Code:String = (arr_results[i] as! NSDictionary)["ICD_Code"] as! String!
                print(let_ICD_Code)
                
                let let_ICD_Long_Description:String = (arr_results[i] as! NSDictionary)["ICD_Long_Description"] as! String!
                print(let_ICD_Long_Description)
                
                let let_ICD_Version:String = (arr_results[i] as! NSDictionary)["ICD_Version"] as! String!
                print(let_ICD_Version)
                
                let str_Combined = "(" + let_ICD_Version +  ") " + let_ICD_Code + " => " + let_ICD_Long_Description
                
                self.txt_Search_Results.text = self.txt_Search_Results.text! + str_Combined + " \n\n"
                
            }
            
            //print(arr_results);
        }
    }
    
    //Alert
    func Alert (Message: String){
        let alertController = UIAlertController(title: "PROMIS-APP-SUITE", message:
            Message,  preferredStyle: UIAlertController.Style.alert);
        alertController.addAction(UIAlertAction(title: "Alert", style: UIAlertAction.Style.default,handler: nil));
        self.present(alertController, animated: true, completion: nil);
    }
    
    @IBAction func btn_Menu(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier :"cls_ViewController_Menu") as! cls_ViewController_Menu;
        viewController.str_User_ID_Navigated=lbl_Menu_User_ID_Email.text!
        viewController.hosting_server = self.hosting_server

        self.present(viewController, animated: true)
    }
    
}
