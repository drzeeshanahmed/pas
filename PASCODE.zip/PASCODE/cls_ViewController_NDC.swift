//
//  cls_ViewController_NDC.swift
//  PAS-Code
//
//  Created by Zeeshan Ahmed.
//  Copyright � 2018 Zeeshan Ahmed. All rights reserved.
//

import UIKit

class cls_ViewController_NDC: UIViewController, UITextFieldDelegate {

    
    @IBOutlet weak var lbl_Menu_User_ID_Email: UILabel!
    var str_User_ID_Navigated = ""
    
    @IBOutlet weak var txt_Search: UITextField!
    @IBOutlet weak var txt_Search_Results: UITextView!
    
    @IBOutlet weak var lbl_Total: UILabel!
    
    var hosting_server = ""
    
    let ACCEPTABLE_CHARACTERS = "ABC"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lbl_Menu_User_ID_Email.text = str_User_ID_Navigated
        self.txt_Search.delegate = self

        // Do any additional setup after loading the view.
    }
    
    //Invoke touch screen
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    //Invoke Return
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txt_Search.resignFirstResponder()
        return (true)
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let cs = CharacterSet(charactersIn: ACCEPTABLE_CHARACTERS).inverted
        let filtered: String = (string.components(separatedBy: cs) as NSArray).componentsJoined(by: "")
        return (string == filtered)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        //Code to run any event at execution.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btn_Menu(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier :"cls_ViewController_Menu") as! cls_ViewController_Menu;
        viewController.str_User_ID_Navigated=lbl_Menu_User_ID_Email.text!
        viewController.hosting_server = self.hosting_server

        self.present(viewController, animated: true)
    }
    
    //Alert
    func Alert (Message: String){
        let alertController = UIAlertController(title: "PROMIS-APP-SUITE", message:
            Message,  preferredStyle: UIAlertController.Style.alert);
        alertController.addAction(UIAlertAction(title: "Alert", style: UIAlertAction.Style.default,handler: nil));
        self.present(alertController, animated: true, completion: nil);
    }
    
    @IBAction func selftxt_Search_Resultstextsearch_Keyword(_ sender: Any) {
        self.txt_Search_Results.text = ""
        search_Keyword()
    }
    
    //Search
    func search_Keyword()
    {
        let str_Keyword = txt_Search.text;
        
        if str_Keyword != ""
        {
            var phpfilename = "tmp_1.php"
            let myURL = NSURL(string: hosting_server + phpfilename);
            
            let request = NSMutableURLRequest(url:myURL! as URL);
            request.httpMethod = "POST";
            
            let postString = "keyword=\(str_Keyword!)";
            
            request.httpBody = postString.data(using: String.Encoding.utf8);
            
            //creating a task to send the post request
            let task = URLSession.shared.dataTask(with: request as URLRequest){
                data, response, error in
                
                if error != nil{
                    print("Session Error \(error)")
                    return;
                }
                else{
                    print("No Session Error")
                }
                
                //parsing the response
                do {
                    //converting resonse to NSDictionary
                    let myJSON =  try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    
                    //getting the JSON array teams from the response
                    let let_results: NSArray = myJSON!["results"] as! NSArray
                    self.Arr_Search_Results(arr_results: let_results)
                    
                } catch {
                    print(error)
                }
            }
            task.resume();
        }
        else
        {
            self.Alert(Message: "Please enter value to search")
            
        }
    }
    
    
    //Search results
    func Arr_Search_Results (arr_results: NSArray){
        print("---Array---")
        
        print ("Total: " + String(arr_results.count))
        
        DispatchQueue.main.async {
            
            //looping through all the json objects in the array teams
            self.lbl_Total.text = "Total: " + String(arr_results.count)

            //looping through all the json objects in the array teams
            for i in 0 ..< arr_results.count{
                //print(teams[i] as! NSDictionary)
                
                let let_Line_Separator:String = "\n" + "----------------------" + "\n"
                
                print(let_Line_Separator)
                
                let let_PRODUCTID:String = (arr_results[i] as! NSDictionary)["PRODUCTID"] as! String!
                
                let let_PRODUCTNDC:String = (arr_results[i] as! NSDictionary)["PRODUCTNDC"] as! String!
                
                let let_PRODUCTTYPENAME:String = (arr_results[i] as! NSDictionary)["PRODUCTTYPENAME"] as! String!
                
                let let_PROPRIETARYNAME:String = (arr_results[i] as! NSDictionary)["PROPRIETARYNAME"] as! String!
                
                let let_NONPROPRIETARYNAME:String = (arr_results[i] as! NSDictionary)["NONPROPRIETARYNAME"] as! String!
                
                let let_DOSAGEFORMNAME:String = (arr_results[i] as! NSDictionary)["DOSAGEFORMNAME"] as! String!
                
                let let_ROUTENAME:String = (arr_results[i] as! NSDictionary)["ROUTENAME"] as! String!
                
                let let_MARKETINGCATEGORYNAME:String = (arr_results[i] as! NSDictionary)["MARKETINGCATEGORYNAME"] as! String!
                
                let let_APPLICATIONNUMBER:String = (arr_results[i] as! NSDictionary)["APPLICATIONNUMBER"] as! String!
                
                let let_LABELERNAME:String = (arr_results[i] as! NSDictionary)["LABELERNAME"] as! String!
                
                let let_SUBSTANCENAME:String = (arr_results[i] as! NSDictionary)["SUBSTANCENAME"] as! String!
                
                let let_ACTIVE_NUMERATOR_STRENGTH:String = (arr_results[i] as! NSDictionary)["ACTIVE_NUMERATOR_STRENGTH"] as! String!
                
                let let_ACTIVE_INGRED_UNIT:String = (arr_results[i] as! NSDictionary)["ACTIVE_INGRED_UNIT"] as! String!
                
                let let_PHARM_CLASSES:String = (arr_results[i] as! NSDictionary)["PHARM_CLASSES"] as! String!
                
                let let_LISTING_RECORD_CERTIFIED_THROUGH:String = (arr_results[i] as! NSDictionary)["LISTING_RECORD_CERTIFIED_THROUGH"] as! String!
                
                let str_Combined = "NDC: " + let_PRODUCTNDC + " \n -TYPE: " + let_PRODUCTTYPENAME + " \n -PROPRIETARY NAME: " + let_PROPRIETARYNAME + " \n -NON PROPRIETARY NAME: " + let_NONPROPRIETARYNAME + " \n -DOSAGE FORM NAME: " + let_DOSAGEFORMNAME  + " \n -ROUTE NAME: " + let_ROUTENAME + " \n -MARKETING CATEGORY NAME: " + let_MARKETINGCATEGORYNAME + " \n -APPLICATION NUMBER: " + let_APPLICATIONNUMBER + " \n -LABELER NAME: " + let_LABELERNAME + " \n -SUBSTANCE NAME: " + let_SUBSTANCENAME + " \n -ACTIVE NUMERATOR STRENGTH: " + let_ACTIVE_NUMERATOR_STRENGTH + " \n -ACTIVE INGRED UNIT: " + let_ACTIVE_INGRED_UNIT + " \n -PHARM CLASSES: " + let_PHARM_CLASSES + " \n -LISTING RECORD CERTIFIED THROUGH: " + let_LISTING_RECORD_CERTIFIED_THROUGH + " \n -PRODUCT ID: " + let_PRODUCTID + let_Line_Separator
                
                print(str_Combined)
                
                self.txt_Search_Results.text = self.txt_Search_Results.text! + str_Combined + " \n\n"
                
            }
            
            //print(arr_results);
        }
    }
    
}
